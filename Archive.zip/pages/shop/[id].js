import React from "react";
import SwagDetails from "../../components/Swags/SwagDetails";
const id = () => {
  return (
    <div className="z-10">
      <SwagDetails />
    </div>
  );
};

export default id;
