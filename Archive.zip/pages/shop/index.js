import React from "react";
import Swags from "../../components/Swags/Swags";
const index = () => {
  return (
    <div>
      <Swags />
    </div>
  );
};

export default index;
