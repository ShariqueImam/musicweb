import client from '@sanity/client';
export default client({
    projectId: 'jhortf5b',
    dataset: 'production',
})