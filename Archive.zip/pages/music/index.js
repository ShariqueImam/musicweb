import React from "react";
import Music from "../../components/Music/Music";
const index = () => {
  return (
    <div>
      <Music />
    </div>
  );
};

export default index;
