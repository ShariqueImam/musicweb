import React from "react";
import Horoscope from "../../components/Horoscope/Horoscope";
const index = () => {
  return (
    <div>
      <Horoscope />
    </div>
  );
};

export default index;
