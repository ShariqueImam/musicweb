import React from "react";
import Live from "../../components/Live/Live";
const index = () => {
  return (
    <div>
      <Live />
    </div>
  );
};

export default index;
